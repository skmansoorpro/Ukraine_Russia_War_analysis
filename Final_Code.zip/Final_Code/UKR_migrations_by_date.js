function draw_UKR_migrations_by_date() {


// set the dimensions and margins of the graph
var margin = {top: 120, right: 420, bottom: 30, left: 150},
  width = 960 - margin.left - margin.right,
  height = 450 - margin.top - margin.bottom;

   
// parse the Date / time
var parseTime = d3.timeParse("%d-%b-%y");

// set the ranges
var x = d3.scaleTime().range([0, width]);
var y = d3.scaleLinear().range([height, 0]);

// define the line
var valueline = d3.line()
    .x(function(d) { return x(d.Date); })
    .y(function(d) { return y(d.Individuals); });

// append the svg obgect to the body of the page
// appends a 'group' element to 'svg'
// moves the 'group' element to the top left margin
var svg = d3.select("#lineChart").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")");

     

// Get the data
d3.csv("https://raw.githubusercontent.com/skmansoorpro/Ukraine_Russia_War_analysis/main/UKR_People_migrated_by_date.csv").then(function(data) {


  // format the data
  data.forEach(function(d) {
      d.Date = parseTime(d.Date);
      d.Individuals = +d.Individuals;
  });

  // Scale the range of the data
  x.domain(d3.extent(data, function(d) { return d.Date; }));
  y.domain([0, d3.max(data, function(d) { return d.Individuals; })]);

  // Add the valueline path.
  svg.append("path")
      .data([data])
      .attr("class", "line")
      .attr("d", valueline);
      
  // Add the scatterplot
  svg.selectAll("dot")
      .data(data)
    .enter().append("circle")
      .filter(function(d) { return d.Individuals > 3000000 })  // <== This line
      .style("fill", "red")                          // <== and this one
      .attr("r", 5)
      .attr("cx", function(d) { return x(d.Date); })
      .attr("cy", function(d) { return y(d.Individuals); })
      .on("mouseover", function(event,d) {
        div.transition()
          .duration(200)
          .style("opacity", .9);
        div.html(d.Individuals)
          .style("left", (event.pageX) + "px")
          .style("top", (event.pageY - 28) + "px");
        })
      .on("mouseout", function(d) {
        div.transition()
          .duration(500)
          .style("opacity", 0);
        })
      ;

  // Add the X Axis
  svg.append("g")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(x));

  // Add the Y Axis
  svg.append("g")
      .call(d3.axisLeft(y));

  // Add labels
  svg.append("text")
    .attr("transform", "translate(" + (width) + "," + y(data[18].Individuals) + ")")
    .attr("dx", "-6em")
    .attr("text-anchor", "end")
    .style("fill", "red")
    .attr("font-size","10px")
    .text("Threshold Warning > 3M");

  // text label for the x axis
  svg.append("text")
    //.attr("transform","translate(" + (width / 2) + " ," +(height + margin.top) + ")")
    .attr("transform","translate(" + (width / 2) + " ," +(height+30) + ")")
    .style("text-anchor", "middle")
    .text("Date")
    .attr("font-size", "10px")
    .style("fill", "gray")
    ;

    // text label for the y axis
    svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 70 - margin.left)
      .attr("x",0 - (height / 2))
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .attr("font-size","10px")
      .style("fill", "gray")
      .text("Migrated Population (Numbers) "); 

// add title
svg.append("text")
   .attr("x", width/2)
   .attr("y", height-320)
   .attr("text-anchor", "middle")
   .style("font-size", "16px")
   .style("font-family","Montserrat")
   .text("Number of People migrated by Date");


});

}