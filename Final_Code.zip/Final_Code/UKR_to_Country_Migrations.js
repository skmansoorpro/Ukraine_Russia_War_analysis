function draw_country_migrations_graph() {
  // Set the dimensions of the canvas / graph
  var margin = { top: 100, right: 20, bottom: 70, left: 150 },
    width = 1000 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;

  // Parse the date / time
  //var parseDate = d3.timeParse("%b %Y");

  var parseDate = d3.timeParse("%d-%b-%y");

  // Set the ranges
  var x = d3.scaleTime().range([0, width]);
  var y = d3.scaleLinear().range([height, 0]);

  // Define the line
  var populationline = d3
    .line()
    .x(function (d) {
      return x(d.date);
    })
    .y(function (d) {
      return y(d.population);
    });

  // Adds the svg canvas
  var svg = d3
    .select("#multilineChart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  // Get the data
  d3.csv(
    "https://raw.githubusercontent.com/skmansoorpro/Ukraine_Russia_War_analysis/main/UKR_People_Migrated_by_Country_refined.csv"
  ).then(function (data) {
    data.forEach(function (d) {
      d.date = parseDate(d.date);
      d.population = +d.population;
    });

    // Scale the range of the data
    x.domain(
      d3.extent(data, function (d) {
        return d.date;
      })
    );
    y.domain([
      0,
      d3.max(data, function (d) {
        return d.population;
      }),
    ]);

    // Group the entries by country
    dataNest = Array.from(
      d3.group(data, (d) => d.country),
      ([key, value]) => ({ key, value })
    );

    // set the colour scale
    var color = d3.scaleOrdinal(d3.schemeCategory10);

    legendSpace = width / dataNest.length; // spacing for the legend

    // Loop through each country / key
    dataNest.forEach(function (d, i) {
      svg
        .append("path")
        .attr("class", "line")
        .style("stroke", function () {
          // Add the colours dynamically
          return (d.color = color(d.key));
        })
        .attr("id", "tag" + d.key.replace(/\s+/g, "")) // assign an ID
        .attr("d", populationline(d.value));

      // Add the Legend
      svg
        .append("text")
        .attr("x", legendSpace / 2 + i * legendSpace) // space legend
        .attr("y", height + margin.bottom / 2 + 5)
        .attr("class", "legend") // style the legend
        .style("fill", function () {
          // Add the colours dynamically
          return (d.color = color(d.key));
        })
        .on("click", function () {
          // Determine if current line is visible
          var active = d.active ? false : true,
            newOpacity = active ? 0 : 1;
          // Hide or show the elements based on the ID
          d3.select("#tag" + d.key.replace(/\s+/g, ""))
            .transition()
            .duration(100)
            .style("opacity", newOpacity);
          // Update whether or not the elements are active
          d.active = active;
        })
        .text(d.key);
    });

    // Add the X Axis
    svg
      .append("g")
      .attr("class", "axis")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(x));

    // text label for the x axis
    svg
      .append("text")
      .attr(
        "transform",
        "translate(" + width / 2 + " ," + (height + margin.top + 30) + ")"
      )
      .style("text-anchor", "middle")
      .text("Date")
      .attr("font-size", "15px")
      .style("fill", "gray");

    // Add the Y Axis
    svg.append("g").attr("class", "axis").call(d3.axisLeft(y));

    // text label for the y axis
    svg
      .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 70 - margin.left)
      .attr("x", 0 - height / 2)
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .attr("font-size", "15px")
      .style("fill", "gray")
      .text("Migrated Population ( Numbers) ");

    // add title
    svg
      .append("text")
      .attr("x", width / 2)
      .attr("y", height - 340)
      .attr("text-anchor", "middle")
      .style("font-size", "16px")
      .style("font-family", "Montserrat")
      .text("Ukraine Refugee movement to Neighbouring Countries");
  });
}
