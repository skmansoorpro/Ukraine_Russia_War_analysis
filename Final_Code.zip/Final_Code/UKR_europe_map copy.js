    function draw_europe_map1(){
    
    // The svg
    const svg = d3.select("#my_dataviz1"),
      width = +svg.attr("width"),
      height = +svg.attr("height");

    // Map and projection
    const projection = d3
      .geoMercator()
      .center([30, 47]) // GPS of location to zoom on
      .scale(500) // This is like the zoom
      .translate([width / 2, height / 2]);

   

    // Create data for invasion circles:
    const markers = [
      { long: 29.115, lat: 51.784, group: "A", size: 34 }, // Belarus
      { long: 34.499, lat: 45.345, group: "A", size: 32 }, // Crimea
      { long: 28.369, lat: 47.411, group: "A", size: 10 }, // Moldova
      { long: 38.087, lat: 50.215, group: "A", size: 88 }, // Russia
      { long: 36.162, lat: 50.242, group: "B", size: 33 }, // Kharkiv, ukr 50.2420179676791, 36.16204034949507
      { long: 35.162, lat: 50.5, group: "B", size: 33 }, // Kharkiv2, ukr 50.2420179676791, 36.16204034949507
      { long: 34.162, lat: 50.5, group: "B", size: 33 }, // Kharkiv2, ukr 50.2420179676791, 36.16204034949507
      { long: 39.162, lat: 48.5, group: "B", size: 33 }, // Kharkiv2, ukr 50.2420179676791, 36.16204034949507
      { long: 39.162, lat: 48.0, group: "B", size: 33 }, // Kharkiv2, ukr 50.2420179676791, 36.16204034949507
      { long: 30.663, lat: 51.277, group: "B", size: 33 }, //51.277268221448054, 30.66374917024254
      { long: 33.513, lat: 46.432, group: "C", size: 33 }, //46.432880819318775, 33.513116790089
      { long: 38.77, lat: 47.98, group: "C", size: 33 }, //47.981412263538985, 38.77556753952669
      { long: 34.88, lat: 46.81, group: "C", size: 33 }, //46.80639736834403, 34.88640769547461
      { long: 30.53, lat: 50.47, group: "C", size: 33 }, //50.47866618286674, 30.529916039435847
      { long: 30.53, lat: 47.153, group: "C", size: 33 }, //47.15303235270886, 37.585884711307145
      { long: 33.17, lat: 52.068, group: "D", size: 55 }, //52.06875553106073, 33.16983606884021
    ];

    // Create data for invasion circles:
    const markers_refugee = [
      { long: 28.175, lat: 53.009, group: "R", size: 11 }, // Belarus 53.009425214137636, 28.175285288110096
      { long: 20.974, lat: 52.185, group: "R", size: 100 }, // Poland 52.18509628527861, 20.9741984199333
      { long: 19.664, lat: 48.855, group: "R", size: 28 }, // Slovakia 48.85592404273613, 19.664426302583543
      { long: 36.05, lat: 53.621, group: "R", size: 35 }, // Russia 53.62191914932058, 36.05092688280052
      { long: 19.705, lat: 47.389, group: "R", size: 36 }, // Hungary, 47.389253135826294, 19.705739510819242
      { long: 24.53, lat: 46.287, group: "R", size: 60 }, // Romania,46.28710779907707, 24.530324272491182
      { long: 28.923, lat: 47.041, group: "R", size: 38 }, // Moldova, 47.041053769671635, 28.924855169725166
    ];

    // Load external data and boot
    d3.json(
      "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson"
    ).then(function (data) {
      // Filter data
      // data.features = data.features.filter( d => d.properties.name=="Ukraine")

      // Create a color scale
      const color = d3
        .scaleOrdinal()
        .domain(["A", "B", "C", "D", "R"])
        .range(["#FF00FF", "#FFA500", "#FF4500", "#FF0000", "#005BBB"]);

      // Add a scale for bubble size
      const size = d3
        .scaleLinear()
        .domain([10, 100]) // What's in the data
        .range([2, 25]); // Size in pixel

    // Three function that change the tooltip when user hover / move / leave a cell
     

      // Draw the map
      svg
        .append("g")
        .selectAll("path")
        .data(data.features)
        .join("path")
        .attr("fill", "#b8b8b8")
        .attr("d", d3.geoPath().projection(projection))
        .style("stroke", "black")
        .style("opacity", 0.5)
  
                ;
//add zoom.pan
        var zoom = d3
        .zoom()
        .scaleExtent([1, 4])
        .on("zoom", function (event) {
          g.selectAll("path").attr("transform", event.transform);
        });

      svg.call(zoom);


 // two function that change the tooltip when user mouseover and mouseout is used
 const mouseover = function (event) {
  d3.select(this)
    .style("fill", "green")
    .transition()};
 

      var mouseout = function (event, d) {
        d3.select(this)
          .style("fill", color(d.group))
          .transition()
          ;

      };

      // Add circles:
      svg
        .selectAll("myCircles")
        .data(markers)
        .join("circle")
        .attr("class", (d) => d.group)
        .attr("cx", (d) => projection([d.long, d.lat])[0])
        .attr("cy", (d) => projection([d.long, d.lat])[1])
        .attr("r", (d) => size(d.size))
        .style("fill", (d) => color(d.group))
        .attr("stroke", (d) => color(d.group))
        .attr("stroke-width", 2)
        .attr("fill-opacity", 0.7)
        .on("mouseover", mouseover)
        .on("mouseout", mouseout);

      // Add refugee circles:

      svg
        .selectAll("myCircles")
        .data(markers_refugee)
        .join("circle")
        .attr("class", (d) => d.group)
        .attr("cx", (d) => projection([d.long, d.lat])[0])
        .attr("cy", (d) => projection([d.long, d.lat])[1])
        .attr("r", (d) => size(d.size))
        .style("fill", (d) => color(d.group))
        .attr("stroke", (d) => color(d.group))
        .attr("stroke-width", 2)
        .attr("fill-opacity", 0.7)
        .on("mouseover", mouseover)
        .on("mouseout", mouseout);

      // This function is gonna change the opacity and size of selected and unselected circles
      function update() {
        // For each check box:
        d3.selectAll(".checkbox").each(function (d) {
          cb = d3.select(this);
          grp = cb.property("value");

          // If the box is check, I show the group
          if (cb.property("checked")) {
            svg
              .selectAll("." + grp)
              .transition()
              .duration(1000)
              .style("opacity", 1)
              .attr("r", function (d) {
                return size(d.size);
              });

            // Otherwise I hide it
          } else {
            svg
              .selectAll("." + grp)
              .transition()
              .duration(1000)
              .style("opacity", 0)
              .attr("r", 0);
          }
        });
      }

      // When a button change, I run the update function
      d3.selectAll(".checkbox").on("change", update);

      // And I initialize it at the beginning
      update();


    });
/*
// add title
svg.append("text")
.attr("x", width-100)
.attr("y", height-375)
.attr("text-anchor", "middle")
.style("font-size", "18px")
.style("font-family","Montserrat")
.text("How was Ukraine attacked?");
*/
// add Ukraine
svg.append("text")
.attr("x", width-200)
.attr("y", height-230)
.attr("text-anchor", "middle")
.style("font-size", "15px")
.style("font-family","Montserrat")
.text("Ukraine");


// add Russia
svg.append("text")
.attr("x", width-110)
.attr("y", height-300)
.attr("text-anchor", "middle")
.style("font-size", "15px")
.style("font-family","Montserrat")
.text("Russia");

// add Belarus
svg.append("text")
.attr("x", width-230)
.attr("y", height-280)
.attr("text-anchor", "middle")
.style("font-size", "15px")
.style("font-family","Montserrat")
.text("Belarus");

// add Poland
svg.append("text")
.attr("x", width-320)
.attr("y", height-280)
.attr("text-anchor", "middle")
.style("font-size", "15px")
.style("font-family","Montserrat")
.text("Poland");

// add Slovakia
svg.append("text")
.attr("x", width-310)
.attr("y", height-220)
.attr("text-anchor", "middle")
.style("font-size", "8px")
.style("font-family","Montserrat")
.text("Slovakia");

// add Hungary
svg.append("text")
.attr("x", width-310)
.attr("y", height-200)
.attr("text-anchor", "middle")
.style("font-size", "8px")
.style("font-family","Montserrat")
.text("hungary");

// add Romania
svg.append("text")
.attr("x", width-260)
.attr("y", height-190)
.attr("text-anchor", "middle")
.style("font-size", "8px")
.style("font-family","Montserrat")
.text("Romania");

}