function draw_russian_exports_treemap(){

  
    // set the dimensions and margins of the graph
    const margin = {top: 50, right: 10, bottom: 10, left: 10},
      width = 950 - margin.left - margin.right,
      height = 450 - margin.top - margin.bottom;
    
    // append the svg object to the body of the page
    const svg = d3.select("#treemapviz")
    .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
    .append("g")
      .attr("transform",
            `translate(${margin.left}, ${margin.top})`);

    var color = d3.scaleOrdinal()
    .domain(["Asia", "Europe", "Africa","North America","South America","Others"])
    .range([ "#ffa500", "#0000FF", "#00FF00","#FFFF00","#FF7F00","#FF0000"])

      // And a opacity scale
  const opacity = d3.scaleLinear()
    .domain([0, 10000])
    .range([.2,1])
    
    // Read data
    d3.csv('https://raw.githubusercontent.com/skmansoorpro/Ukraine_Russia_War_analysis/main/TIV-Export-RUS-2016-2021.csv').then(function(data) {
    
      // stratify the data: reformatting for d3.js
      const root = d3.stratify()
        .id(function(d) { return d.Country; })   // Name of the entity (column name is name in csv)
        .parentId(function(d) { return d.Continent; })   // Name of the parent (column name is parent in csv)
        (data);
      root.sum(function(d) { return +d.Total })   // Compute the numeric value for each entity
    

      // Then d3.treemap computes the position of each element of the hierarchy
      // The coordinates are added to the root object above
      d3.treemap()
        .size([width, height])
        .padding(4)
        (root)
    
      // use this information to add rectangles:
      svg
        .selectAll("rect")
        .data(root.leaves())
        .join("rect")
          .attr('x', function (d) { return d.x0; })
          .attr('y', function (d) { return d.y0; })
          .attr('width', function (d) { return d.x1 - d.x0; })
          .attr('height', function (d) { return d.y1 - d.y0; })
          .style("stroke", "black")
          .style("opacity", function(d){ return opacity(d.data.Total)})
          .style("fill", function (d) {return color(d.data.Continent)});
    
      // and to add the text labels
      svg
        .selectAll("text")
        .data(root.leaves())
        .join("text")
          .attr("x", function(d){ return (d.x0+05)})    // +10 to adjust position (more right)
          .attr("y", function(d){ return (d.y0+10)})    // +20 to adjust position (lower)
          .text(function(d){ return d.data.Country})
          .attr("font-size", "10px")
          .attr("fill", "black");

          // add title
svg.append("text")
.attr("x", width/2)
.attr("y", height-400)
.attr("text-anchor", "middle")
.style("font-size", "16px")
.style("font-family","Montserrat")
.text("Russia's biggest arm buyers");

 // Add title for the each group
 svg
 .selectAll("titles")
 .data(root.descendants().filter(function(d){return d.depth==1}))
 .enter()
 .append("text")
   .attr("x", function(d){ return d.x0})
   .attr("y", function(d){ return d.y0})
   .text(function(d){ return d.data.Country })
   .attr("font-size", "12px")
   .attr("fill",  function(d){ return color(d.data.Country)} )



    })
}